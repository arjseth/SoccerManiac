class Tar {
  constructor(x, y, color, size, goal) {
    this.x = x;
    this.y = y;
    this.color = color;
    this.size = 30;
    this.goal = goal;
  }
  update() {
    
  }
  show(x, y) {
    if (this.goal) {
      this.color = color(0, 0, 0)
    }
    fill(this.color);
    ellipse(this.x, this.y, this.size, this.size);
    
 
  }
}



//let size = 30;

//function tar() {
//strokeWeight(2);
//stroke("green");
//fill(255,0,0,0);
//var targ = [
//"ellipse(250, 110, size, size)",
//"ellipse(185, 90, size, size)",
//"ellipse(185, 135, size, size)",
//"ellipse(315, 135, size, size)",
//"ellipse(315, 90, size, size)"
//]
//for (var i = 0; i < targ.length; i++) {
//  eval(targ[i]);
//}
//}
